#ifndef TASK_INTERFACE_H_
#define TASK_INTERFACE_H_

#include "interface.h"
#include "main.h"
extern u8g2_t u8g2_obj;

static void init_u8g2();
void send_buffer_u8g2();
void displayOled();

#endif
