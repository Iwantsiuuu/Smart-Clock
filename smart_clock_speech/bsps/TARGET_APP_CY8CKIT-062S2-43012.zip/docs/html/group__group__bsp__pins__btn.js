var group__group__bsp__pins__btn =
[
    [ "CYBSP_SW2", "group__group__bsp__pins__btn.html#ga66053f56ad1d1992e7059a8734d8de14", null ],
    [ "CYBSP_SW4", "group__group__bsp__pins__btn.html#ga071fbb612b81a7f62b2e750211ba985a", null ],
    [ "CYBSP_USER_BTN", "group__group__bsp__pins__btn.html#ga72717d2a6e1a64352274dfb2e5649ee9", null ],
    [ "CYBSP_USER_BTN1", "group__group__bsp__pins__btn.html#ga719bfb6bb0a640a38d94febf75e45341", null ],
    [ "CYBSP_USER_BTN2", "group__group__bsp__pins__btn.html#ga820739c877e26f84c57a259d5c561d8f", null ]
];