var modules =
[
    [ "Error Codes", "group__group__bsp__errors.html", "group__group__bsp__errors" ],
    [ "Functions", "group__group__bsp__functions.html", "group__group__bsp__functions" ],
    [ "Pin Mappings", "group__group__bsp__pins.html", "group__group__bsp__pins" ],
    [ "Pin States", "group__group__bsp__pin__state.html", "group__group__bsp__pin__state" ],
    [ "Bluetooth Configuration Structure", "group__group__bsp__bt.html", "group__group__bsp__bt" ]
];